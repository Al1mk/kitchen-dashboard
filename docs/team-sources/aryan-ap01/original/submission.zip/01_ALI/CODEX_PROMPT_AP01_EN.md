# Task for Codex / AI coding agent — Aryan AP-01, HCI Campus Board

Repository: https://github.com/Al1mk/kitchen-dashboard
Baseline used to prepare this handoff: main at a7903db512b6e98ebbe7783ddc64c2da89543a23 (2026-11-01). Check the current HEAD first, do not assume it is unchanged.

Skills to inspect/install only after reviewing their code and according to your local permissions:
1. Microsoft Playwright CLI: https://github.com/microsoft/playwright-cli/blob/main/skills/playwright-cli/SKILL.md
2. UI UX Pro Max: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill

The original AP-01 code package is `AP01_READY_FOR_ALI_2026-11-03.zip` in the same handoff folder. The task is to review, safely apply, debug, and verify Aryan's clustered map markers in the current Next.js application. Do not redesign unrelated modules or overwrite teammates' branches.

### Required actions
1. Clone the repository into a clean local directory, inspect README.md, docs/contracts.md, docs/contributions.md and map-related tests. Check Node >=22.18.0 and the current branch/SHA. Create a dedicated feature branch. Do not push/merge without Ali's review.
2. Read the supplied patch README, run the patcher in `--dry-run` mode first; if its anchors no longer match, STOP, inspect the current CampusMap.tsx and integrate safely by hand. Preserve existing navigation, room IDs, floor geometry, booking links and language state. Never auto-overwrite shared CSS, DB or APIs.
3. Inspect UI/UX on an actual simulated portrait kiosk and desktop with Playwright CLI snapshots and screenshots. Explicitly distinguish emulator observations from actual Elo hardware. Address nearby markers via a cluster/list (or clearly justified equivalent), not by blindly enlarging overlapping hit targets. Test K1-115 and K1-118 in fit mode and after zoom.
4. Run `npm ci`, `npm run typecheck`, `npm run lint`, `npm test`, `npm run test:e2e`, `npm run build` using the correct local demo database. Test map search (K1-120 and 120), change floor, zoom/pan, DE/EN, keyboard focus, room ID URL, room details, scheduling/booking deep-links, image failure and browser history. Record failures honestly; no invented PASS results.
5. Capture equivalent *before* and *after* screenshots with the SAME viewport, zoom, floor and data. Show problem -> exact change -> HCI reasoning -> observed result. A captured V2 result is valid only if the new code has actually run.
6. Provide **only changed/new files relative to the current repository** in one clean directory for Ali, preserving relative paths, plus `git diff`, an integration README, screenshots and machine-readable test log. Clearly document if the code could not be run. Do NOT include .env.local, SQLite databases, personal information, credentials, node_modules or .next.

### Acceptance
- Every selectable room has an unambiguous path, including 115/118.
- No obscured targets in the actual DOM geometry at the supported widths.
- No regressions of search, links, room IDs, language and booking.
- Code passes checks or unresolved failures are explicitly listed.
- Evidence labels distinguish 'planned', 'implemented', 'automated tested', 'manual tested', and 'real-user tested'.
- Public routes remain clearly demo-only; AI floor illustrations are not official maps.

Report to Ali: branch name + baseline SHA + changed file list + test outcomes + screenshots + unresolved issues + ready-for-review decision.
