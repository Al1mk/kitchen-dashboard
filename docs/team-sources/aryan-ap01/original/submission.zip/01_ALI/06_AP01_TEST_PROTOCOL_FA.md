# AP-01 / T44 — پروتکل آزمون نقشه برای آریان (V2)
**این یک پروتکل آزمون است و هیچ کدام از نتیجه‌ها بدون اجرا PASS نیستند.**

## ثبت اولیه
| فیلد | مقدار |
|---|---|
| Commit / SHA | TODO |
| شاخه / dirty status | TODO |
| تاریخ / اجراکننده | TODO |
| دستگاه واقعی یا emulator | TODO |
| عرض/ارتفاع CSS viewport | TODO |
| Zoom OS / browser / map | TODO |
| نوع ورودی: touch/mouse/keyboard | TODO |
| AL-02 navbar reserved height / token | TODO |

## جدول الزامی تست
| شناسه | کاربر چه می‌کند | انتظار | نتیجه واقعی |
|---|---|---|---|
| M-01 | روی 1OG در fit دنبال K1-115/K1-118 می‌گردد | cluster/list یا callout بدون لمس اتاق اشتباه؛ هیچ hit target پوشیده | NOT RUN |
| M-02 | zoom کافی و لمس دقیق مرکز K1-115، سپس K1-118 | هر بار `selected.id` و کد خود همان اتاق | NOT RUN |
| M-03 | طبقات 2OG و 3OG؛ بررسی همه برخوردها | انتخاب بی‌ابهام و عدم هدف لمس پنهان | NOT RUN |
| M-04 | جست‌وجوی K1-120، 120، K1-215a، 215b و نام DE/EN | نتیجه صحیح، طبقه مناسب، حفظ language | NOT RUN |
| M-05 | تغییر طبقه بعد از انتخاب اتاق | انتخاب قبلی پاک، markerهای طبقه جدید صحیح | NOT RUN |
| M-06 | زوم + drag/pan + fit | مختصات نرمال‌شده و پیوند نقطه به تصویر حفظ | NOT RUN |
| M-07 | لینک مستقیم `/map?raum=<stable-room-id>&lang=en` | room انتخاب شود؛ link به schedule/booking با همان id | NOT RUN |
| M-08 | اتاق K1-114 | فقط در لیست، بدون نقطه ساختگی | NOT RUN |
| M-09 | خطای تصویر یک طبقه یا درخواست API | پیام قابل فهم؛ امکان فهرست اتاق‌ها تا حد داده موجود | NOT RUN |
| M-10 | استفاده از keyboard Tab/Enter و Focus | همه کنترل‌ها focusable، مشخص، نشانه فعال فقط رنگی نباشد | NOT RUN |
| M-11 | روی نمایشگر واقعی Elo در حالت تمام‌صفحه | لمس، viewport، zoom، نوار پایین و keyboard واقعی ثبت شود | NOT RUN |
| M-12 | User U2: پیدا کردن K1-120 و فردا در schedule | موفقیت/کمک/زمان/ابهام فقط طبق مشاهده ثبت شود | NOT RUN |

## شواهد لازم
- برای هر تغییر `Problem → Evidence → Change → Result`.
- عکس قبل/بعد از همان viewport/floor/zoom/data؛ cropها یکسان؛ شبیه‌سازی از سخت‌افزار متمایز.
- شمار جفت‌برخورد طبق `MAP_MARKER_44PX_CONFLICTS.csv` **پیش از V2**؛ بعد با اجرای layout واقعی/DOM اندازه‌گیری شود؛ صرف فاصلهٔ نقطه‌ها برای شمار برخورد پس از تغییر کافی نیست.
- تست‌های `tests/e2e/map-integration.spec.ts`, `tests/unit/map-config.test.ts`، و سناریوهای navigation/booking که ممکن است V2 آنها را متاثر کند؛ نتایج در تاریخ واقعی.
- تست کاربران واقعی فقط با داوطلب، روش و تعداد ثبت‌شده؛ هیچ جمع‌بندی رضایت قبل از پاسخ‌ها.
